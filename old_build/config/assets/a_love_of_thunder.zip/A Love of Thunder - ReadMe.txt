A LOVE OF THUNDER
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

This one doesn't have a complicated origin story. I love the warm stressing on my "Dirty Headline" font, and I wanted to create a brother-font for it; similarly stressed but with an alternate style, for some mixed graphics. For the base forms, I went to one of my favorite fonts from the 1920s, and dipped it in the same acid-pit (or rather, a very similar one) as DH. The main differences are less stressing on the outlines, a bit more texture and "resolution," and less vertical precision; this one hangs looser on the baseline. Other than that, A LOVE OF THUNDER is a full-keyboard small-caps set with one or two of the usual extras. Enjoy!

This font is copyright � 2009 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for private, non-commercial use. Contact me at sjohn@cumberlandgames.com if you're interested in a public-use or organizational license.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0
