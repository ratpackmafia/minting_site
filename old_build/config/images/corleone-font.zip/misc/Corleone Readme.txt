 ___   __  _  _  ____  __  __  ___  ___   __      __  __  __  __ 
(  _) /  \( \( )(_  _)(  \/  )(  _)/ __) (  )    / _)/  \(  \/  )
 ) _)( () ))  (   )(   )    (  ) _)\__ \ /__\  _( (_( () ))    ( 
(_)   \__/(_)\_) (__) (_/\/\_)(___)(___/(_)(_)(_)\__)\__/(_/\/\_)

Font Name - Corleone and Corleone Due v1.0 (Freeware)
*******************************************************
Release Date - December 7, 2001
Designed by Michael Hagemann at www.FontMesa.com
Available for PC Truetype and Type1
Available for Mac in Type1
International Characters: Yes
Euro symbol: Yes
Kerning: Yes
Platform: Win95, Win98, WinME, Win2000, WinXP

++++++++++++++++++++++++++++++++++++++++++++++++++++++++
FontMesa Freeware
++++++++++++++++++++++++++++++++++++++++++++++++++++++++


The Corleone font resembles the style of lettering used in
the Godfather movies. The original logo from the first movie
was too tightly spaced and didn't work well as a font but the
Godfather logo from the third movie was better spaced and worked
well even at smaller type sizes.

The first Corleone font has an upper case with an extended top line
while the second font Corleone Due has normal upper case letters

There are three ligatures or custom letter combinations in the fonts,
the custom letters (th) are located on the less than key and can be 
acsessed by holding down the shift key and pressing the comma key.
Another custom letter (tt) is located on the greater than key and can be 
accessed by holding down the shift key and pressing the period key.
And a third custom ligature (Th) is located on the vertical bar key and 
can acsessed by holding down the shift key and pressing the back slash key.

And last there is the hand holding the puppet strings symbol located on
the at key (@) and can be accessed by holding down the shift key and pressing 
the number two key.


I hope you enjoy this font as much as I do.

Michael

